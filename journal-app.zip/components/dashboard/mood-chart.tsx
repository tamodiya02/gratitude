import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function MoodChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Mood Trends</CardTitle>
        <CardDescription>Your emotional patterns over time.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] flex items-center justify-center text-muted-foreground">
          {/* In a real app, you would use a chart library like recharts or chart.js */}
          <div className="flex space-x-2 items-end h-full pb-6">
            <div className="w-8 bg-primary/10 h-[20%] rounded-t-md"></div>
            <div className="w-8 bg-primary/20 h-[40%] rounded-t-md"></div>
            <div className="w-8 bg-primary/30 h-[70%] rounded-t-md"></div>
            <div className="w-8 bg-primary/40 h-[90%] rounded-t-md"></div>
            <div className="w-8 bg-primary/50 h-[60%] rounded-t-md"></div>
            <div className="w-8 bg-primary/60 h-[80%] rounded-t-md"></div>
            <div className="w-8 bg-primary/70 h-[50%] rounded-t-md"></div>
          </div>
        </div>
        <div className="flex justify-between text-xs text-muted-foreground mt-2">
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
          <div>Sun</div>
        </div>
      </CardContent>
    </Card>
  )
}
