import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { JournalStats } from "@/components/dashboard/journal-stats"
import { RecentEntries } from "@/components/dashboard/recent-entries"
import { MoodChart } from "@/components/dashboard/mood-chart"
import { DailyPrompt } from "@/components/dashboard/daily-prompt"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/sign-in")
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" text="View your journaling stats and recent entries." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <JournalStats />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-1 md:col-span-1 lg:col-span-4">
          <RecentEntries />
        </div>
        <div className="col-span-1 md:col-span-1 lg:col-span-3">
          <div className="grid gap-4">
            <MoodChart />
            <DailyPrompt />
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}
