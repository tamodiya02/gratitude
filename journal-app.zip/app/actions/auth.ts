"use server"

import { revalidatePath } from "next/cache"
import { hash } from "bcrypt"
import { prisma } from "@/lib/prisma"

export async function registerUser(formData: FormData) {
  try {
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const password = formData.get("password") as string

    if (!name || !email || !password) {
      return { error: "All fields are required" }
    }

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return { error: "User with this email already exists" }
    }

    // Hash the password
    const hashedPassword = await hash(password, 10)

    // Create the user
    const user = await prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        settings: {
          create: {
            reminderTime: "20:00",
            dailyPromptsEnabled: true,
            weeklyEmailEnabled: true,
            aiAnalysisEnabled: true,
            theme: "system",
          },
        },
      },
    })

    revalidatePath("/sign-in")
    return { success: true, userId: user.id }
  } catch (error) {
    console.error("Error registering user:", error)
    return { error: "Failed to register user" }
  }
}

export async function updateUserProfile(userId: string, formData: FormData) {
  try {
    const name = formData.get("name") as string

    if (!name) {
      return { error: "Name is required" }
    }

    // Update the user
    await prisma.user.update({
      where: { id: userId },
      data: { name },
    })

    revalidatePath("/settings")
    return { success: true }
  } catch (error) {
    console.error("Error updating user profile:", error)
    return { error: "Failed to update profile" }
  }
}

export async function updateUserSettings(userId: string, formData: FormData) {
  try {
    const reminderTime = formData.get("reminderTime") as string
    const dailyPromptsEnabled = formData.get("dailyPromptsEnabled") === "on"
    const weeklyEmailEnabled = formData.get("weeklyEmailEnabled") === "on"
    const aiAnalysisEnabled = formData.get("aiAnalysisEnabled") === "on"
    const theme = formData.get("theme") as string

    // Update or create user settings
    await prisma.userSettings.upsert({
      where: { userId },
      update: {
        reminderTime,
        dailyPromptsEnabled,
        weeklyEmailEnabled,
        aiAnalysisEnabled,
        theme,
      },
      create: {
        userId,
        reminderTime,
        dailyPromptsEnabled,
        weeklyEmailEnabled,
        aiAnalysisEnabled,
        theme,
      },
    })

    revalidatePath("/settings")
    return { success: true }
  } catch (error) {
    console.error("Error updating user settings:", error)
    return { error: "Failed to update settings" }
  }
}
