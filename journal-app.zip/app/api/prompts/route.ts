import { NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function GET() {
  try {
    // Generate a daily prompt using AI
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt:
        "Generate a thoughtful journaling prompt that encourages self-reflection and personal growth. The prompt should be a single question or statement that inspires deep thinking.",
      maxTokens: 100,
    })

    return NextResponse.json({ prompt: text.trim() })
  } catch (error) {
    console.error("Error generating prompt:", error)
    return NextResponse.json({ error: "Failed to generate prompt" }, { status: 500 })
  }
}
